Ahmed body: an end-to-end CFD surrogate study

Evidence package generated 2026-10-25T18:32:06.828Z.
MANIFEST.json lists the SHA-256 of every file; sources/ holds the original artifacts unchanged.
A test is reported as passed only when evidence-ledger.json holds an intact record of its run.
