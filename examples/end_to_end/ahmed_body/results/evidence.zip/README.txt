Ahmed body: an end-to-end CFD surrogate study

Evidence package generated 2026-10-31T05:45:41.344Z.
MANIFEST.json lists the SHA-256 of every file; sources/ holds the original artifacts unchanged.
A test is reported as passed only when evidence-ledger.json holds an intact record of its run.
